db.unicorns.updateOne(
    {name: 'Roooooodles'},
    {$set: {weight: 590}}
);