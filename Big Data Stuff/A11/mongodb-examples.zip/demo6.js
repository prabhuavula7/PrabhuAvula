db.unicorns.find({name: 'Roooooodles'}).forEach(function (doc) { 
printjson (doc);
})

